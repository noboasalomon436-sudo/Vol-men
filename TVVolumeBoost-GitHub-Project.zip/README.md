# TV Volume Boost

App Android/Android TV con control de volumen por voz y deslizador BOOST 0–100. El BOOST solicita hasta +10 dB mediante Android `LoudnessEnhancer` en la salida global (sesión 0); el firmware puede bloquear ese efecto o limitarlo. No se puede garantizar la amplificación global en todos los televisores.

## Compilar en GitHub
1. Sube todo el contenido del proyecto a la raíz de un repositorio.
2. Abre Actions y ejecuta **Build Android APK** (también se activa al hacer push a `main`).
3. Descarga el artefacto `TVVolumeVoice-debug-apk`; contiene `app-debug.apk`.

BOOST 100 no equivale a 100 dB: es el 100% del control de boost de la app, con objetivo máximo de +10 dB. Aumenta gradualmente para evitar distorsión o volumen excesivo.
