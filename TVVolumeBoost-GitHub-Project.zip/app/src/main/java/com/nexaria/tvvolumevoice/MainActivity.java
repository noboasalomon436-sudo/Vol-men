package com.nexaria.tvvolumevoice;

import android.app.Activity;
import android.os.Bundle;
import android.media.AudioManager;
import android.media.audiofx.LoudnessEnhancer;
import android.content.Context;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.widget.*;
import android.view.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private AudioManager audio;
    private TextView status, volumeValue, boostValue;
    private SeekBar volumeSlider, boostSlider;
    private int maxVolume;
    private LoudnessEnhancer enhancer;
    private final int REQUEST_SPEECH = 44;
    private int boostPercent = 0;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        audio = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        maxVolume = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        try {
            // Session 0 requests an output-mix effect. Some TV firmwares do not support it.
            enhancer = new LoudnessEnhancer(0);
            enhancer.setEnabled(true);
        } catch (Exception e) {
            enhancer = null;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 18, 32, 18);
        root.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("TV VOLUME BOOST");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp());

        status = new TextView(this);
        status.setText("Amplificador de audio · control por voz");
        status.setTextColor(0xFFB9D8E8);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        root.addView(status, lp());

        volumeValue = new TextView(this);
        volumeValue.setTextColor(0xFFFFFFFF);
        volumeValue.setTextSize(21);
        volumeValue.setGravity(Gravity.CENTER);
        root.addView(volumeValue, lp());

        volumeSlider = new SeekBar(this);
        volumeSlider.setMax(100);
        volumeSlider.setProgress(getVolumePercent());
        root.addView(volumeSlider, lp());
        volumeSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                if (user) setVolumePercent(p);
                updateLabels();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        boostValue = new TextView(this);
        boostValue.setTextColor(0xFF69E5FF);
        boostValue.setTextSize(24);
        boostValue.setGravity(Gravity.CENTER);
        root.addView(boostValue, lp());

        boostSlider = new SeekBar(this);
        boostSlider.setMax(100);
        boostSlider.setProgress(0);
        root.addView(boostSlider, lp());
        boostSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                boostPercent = p;
                applyBoost(p);
                updateLabels();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        LinearLayout buttons = new LinearLayout(this);
        buttons.setGravity(Gravity.CENTER);
        Button down = new Button(this); down.setText("− Volumen");
        Button up = new Button(this); up.setText("+ Volumen");
        Button voice = new Button(this); voice.setText("🎙 Hablar");
        buttons.addView(down); buttons.addView(up); buttons.addView(voice);
        root.addView(buttons, lp());
        down.setOnClickListener(v -> setVolumePercent(Math.max(0, getVolumePercent()-10)));
        up.setOnClickListener(v -> setVolumePercent(Math.min(100, getVolumePercent()+10)));
        voice.setOnClickListener(v -> listen());

        TextView note = new TextView(this);
        note.setText("BOOST 0–100: solicita hasta +10 dB mediante LoudnessEnhancer. El efecto global depende del firmware; algunas TV no permiten amplificar el audio de otras apps. Sube poco a poco para evitar distorsión y volumen excesivo.");
        note.setTextColor(0xFFFFD28A);
        note.setTextSize(14);
        note.setGravity(Gravity.CENTER);
        root.addView(note, lp());

        setContentView(root);
        applyBoost(0);
        updateLabels();
    }

    private LinearLayout.LayoutParams lp() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int getVolumePercent() {
        int now = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        return maxVolume == 0 ? 0 : Math.round(now * 100f / maxVolume);
    }

    private void setVolumePercent(int percent) {
        int p = Math.max(0, Math.min(100, percent));
        int target = Math.round(p * maxVolume / 100f);
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0);
        if (volumeSlider != null) volumeSlider.setProgress(p);
        updateLabels();
    }

    private void applyBoost(int p) {
        // Android LoudnessEnhancer accepts target gain in millibels. 1000 mB = +10 dB.
        // UI reaches 100; actual global application depends on device support.
        try {
            if (enhancer != null) {
                enhancer.setTargetGain(Math.max(0, Math.min(100, p)) * 10);
                enhancer.setEnabled(p > 0);
            }
        } catch (Exception e) {
            status.setText("Este televisor bloquea el boost global. Prueba con audio compatible.");
        }
    }

    private void updateLabels() {
        if (volumeValue != null) volumeValue.setText("Volumen del sistema: " + getVolumePercent() + "%");
        if (boostValue != null) {
            int db10 = boostPercent;
            boostValue.setText("BOOST: " + boostPercent + "%  ·  hasta +" + (db10 / 10.0) + " dB");
        }
    }

    private void listen() {
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, new Locale("es", "DO"));
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Di: volumen 60, boost 80, subir volumen o bajar volumen");
            startActivityForResult(intent, REQUEST_SPEECH);
        } catch (Exception e) {
            status.setText("El reconocimiento de voz no está disponible en este dispositivo.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results == null || results.isEmpty()) return;
            String spoken = results.get(0).toLowerCase(new Locale("es", "DO"));
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,3})").matcher(spoken);
            if (spoken.contains("boost") && m.find()) {
                int p = Math.max(0, Math.min(100, Integer.parseInt(m.group(1))));
                boostPercent = p;
                boostSlider.setProgress(p);
                applyBoost(p);
                status.setText("Boost ajustado a " + p + "%.");
            } else if (spoken.contains("subir") || spoken.contains("aumentar")) {
                setVolumePercent(Math.min(100, getVolumePercent()+10));
                status.setText("Subiendo el volumen.");
            } else if (spoken.contains("bajar") || spoken.contains("disminuir")) {
                setVolumePercent(Math.max(0, getVolumePercent()-10));
                status.setText("Bajando el volumen.");
            } else if (spoken.contains("silencio") || spoken.contains("mute")) {
                setVolumePercent(0);
                status.setText("Volumen en silencio.");
            } else if (m.find(0)) {
                int p = Math.max(0, Math.min(100, Integer.parseInt(m.group(1))));
                setVolumePercent(p);
                status.setText("Volumen ajustado a " + p + "%.");
            } else {
                status.setText("Prueba: «volumen 60», «boost 80» o «subir volumen».");
            }
        }
    }

    @Override protected void onDestroy() {
        if (enhancer != null) {
            try { enhancer.setEnabled(false); enhancer.release(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
